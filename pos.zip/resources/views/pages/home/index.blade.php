@extends('layouts.app')

@section('content')
    <div class="card">
        <div class="card-body">Basic card</div>
    </div>

@endsection