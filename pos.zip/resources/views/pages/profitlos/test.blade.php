<?php
$str = "Select all images of Shat Gombuj Mosque, Bagerhat";
$str=explode("images of",$str);
echo $str[0]." images of";
?> 