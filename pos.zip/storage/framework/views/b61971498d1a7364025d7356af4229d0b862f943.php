<?php $__env->startSection('title', 'Show Sells'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <div class="panel-body">
                    
                    <div class="" style="vertical-align: middle; text-align: center;">
                                <address>
                                    <img class="logo img-thumbnail" src="/image/<?php echo e(Session::get('outlet_image')); ?>"style="
                                    width: 100px; />

                                    <div class="info">
                                        <p><strong><?php echo e(Session::get('outlet_name')); ?></strong></p>
                                        <p><?php echo e(Session::get('outlet_address')); ?></p>
                                    </div>
                                    
                                    

                                </address>
                            </div>
                    <div class="row">
                        <div class="col-md-12">

                            <div class="pull-left m-t-30">
                                <address>

                                    <strong><?php echo e($details->customer_name); ?></strong><br>
                                    <?php echo e($details->customer_address); ?><br>
                                    <abbr title="Phone">P:</abbr> <?php echo e($details->customer_phone); ?>

                                </address>
                            </div>

                            

                            <div class="pull-right m-t-30">
                                <h4 class="font-16">Invoice #
                                    <strong><?php echo e($details->invoice); ?></strong>
                                </h4>
                                <p><strong>Order Date: </strong> <?php echo e(date('d-M-Y', strtotime($details->created_at))); ?></p>
                                <p class="m-t-10"><strong>Paid Status: </strong> <?php if($details->paid_status==1): ?><span
                                            class="label label-default">Paid</span> <?php else: ?> <span
                                            class="label label-info">Pending</span></p> <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                    
                    <?php if($result): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table m-t-30">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Item</th>
                                            
                                            <th>Quantity</th>
                                            <th>Unit Cost</th>
                                            <th>Total</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php ($i=1); ?>
                                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($res->product_title); ?></td>
                                                
                                                <td><?php echo e($res->quantity); ?></td>
                                                <td>$ <?php echo e($res->unit_price); ?></td>
                                                <td>$ <?php echo e($res->quantity*$res->unit_price); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>

                        
                      <div class="row">
                        <div  class="col-md-6">
                            <div class="row" >


                               <?php if(isset($prevDue)): ?>
                                Previous Due:<?php echo e($prevDue); ?>Tk
                               <?php endif; ?>
                               <?php if(empty($prevDue)): ?>
                        
                               
                               <?php endif; ?>
                            </div>
                        </div>

                                
                        <div  class="col-md-6" >


                                    <div class=" justify-content-end float-right">
                                        <div class="col-md-12">
                                            <p class="text-right">
                                                <b>Sub-total:</b>
                                                $ <?php echo e($details->grand_total_price+$details->discount_amount+$details->total_vat); ?>

                                            </p>
                                            <p class="text-right"><b>Discout:</b> $ <?php echo e($details->discount_amount); ?></p>
                                            <p class="text-right"><b>VAT: </b>$ <?php echo e($details->total_vat); ?></p>
                                            <p class="text-right"><b>Due: </b>
                                                <?php if($details->paid_status==1): ?> 0

                                                <?php else: ?>
                                                <?php echo e(($details->grand_total_price+$details->discount_amount+$details->total_vat) - ($details->given_amount)); ?>

                                                <?php endif; ?>
                                            </p>
                                            <hr>
                                            <h3 class="text-right">Grand Total: $ <?php echo e($details->grand_total_price); ?></h3>
                                        </div>
                                    </div>
                                </div>
                                

                                
                       </div>
                        

                        
                    <?php endif; ?>
                    <hr>
                    <div class="d-print-none">
                        <div class="text-right">
                            <a href="javascript:window.print()" class="btn btn-inverse waves-effect waves-light"><i
                                        class="fa fa-print"></i></a>
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <!-- end row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>