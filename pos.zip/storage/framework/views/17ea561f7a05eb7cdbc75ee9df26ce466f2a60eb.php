<?php $__env->startSection('title', 'Show Sells'); ?>

<?php $__env->startSection('content'); ?>
    <link href="/css/pos.css" rel="stylesheet" type="text/css"/>

    <div class="pull-left">
        <div class="d-print-none">
            <div class="text-right">
                <a href="javascript:window.print()" class="btn btn-inverse waves-effect waves-light"><i
                            class="fa fa-print"></i></a>
                            
                
            </div>
        </div>
    </div>


    <div id="invoice-POS">
        <p>
            <small><?php echo e($invoice); ?>/ <?php echo e(date('d-M')); ?></small>
        </p>

        <center id="top">

            <img class="logo img-thumbnail" src="/image/<?php echo e(Session::get('outlet_image')); ?>"/>

            <div class="info">
                <p><strong><?php echo e(Session::get('outlet_name')); ?></strong></p>
                <p><?php echo e(Session::get('outlet_address')); ?></p>
            </div><!--End Info-->
        </center><!--End InvoiceTop-->

        <div id="mid">
            <div class="info">
                <h2>Contact Info</h2>
                <p>Name : <?php echo e($details->customer_name); ?></p>
                <p>Phone : <?php echo e($details->customer_phone); ?></p>
                <p>Address : <?php echo e($details->customer_address); ?></p>
            </div>
        </div><!--End Invoice Mid-->

        <div id="bot">

            <div id="table">
                <table>
                    <tr class="tabletitle">
                        <td class="item"><h2>Item</h2></td>
                        <td class="Hours"><h2>Qty</h2></td>
                        <td class="Rate"><h2>Sub Total</h2></td>
                    </tr>


                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="service">
                            <td class="tableitem"><p class="itemtext"><?php echo e($res->product_title); ?></p></td>
                            <td class="tableitem"><p class="itemtext"><?php echo e($res->quantity); ?></p></td>
                            <td class="tableitem"><p class="itemtext">$ <?php echo e($res->quantity*$res->unit_price); ?></p></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <tr class="tabletitle">
                        <td></td>
                        <td class="Rate"><h2>Vat</h2></td>
                        <td class="payment"><h2>$ <?php echo e($details->total_vat); ?></h2></td>
                    </tr>
                    <tr class="tabletitle">
                        <td></td>
                        <td class="Rate"><h2>Discount</h2></td>
                        <td class="payment"><h2>$ <?php echo e($details->discount_amount); ?></h2></td>
                    </tr>


                    <tr class="tabletitle">
                        <td></td>
                        <td class="Rate"><h2>Due</h2></td>
                        <td class="payment"><h2>
                                <?php if($details->paid_status==1): ?> 0

                                <?php else: ?>
                                    <?php echo e(($details->grand_total_price+$details->discount_amount+$details->total_vat)- ($details->given_amount)); ?>

                                <?php endif; ?>
                            </h2>
                        </td>
                    </tr>



                    <tr class="tabletitle">
                        <?php if(isset($prevDue)): ?>
                        <td>Previous Due:<?php echo e($prevDue); ?>Tk</td>
                        <?php endif; ?>
                        <?php if(empty($prevDue)): ?>
                        <td></td>
                        <?php endif; ?>
                        
                        <td class="Rate"><h2>Total</h2></td>
                        <td class="payment"><h2>
                                $ <?php echo e($details->grand_total_price+$details->discount_amount+$details->total_vat); ?></h2>
                        </td>
                    </tr>

                </table>
            </div><!--End Table-->

            <div id="legalcopy">
                <p class="legal"><strong>Thank you for visiting us!</strong><br>Have a good day.
                </p>
            </div>

        </div><!--End InvoiceBot-->
    </div><!--End Invoice-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>