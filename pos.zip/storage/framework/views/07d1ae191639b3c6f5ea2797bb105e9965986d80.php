<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title"><?php echo e(__("message.products")); ?></h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/"><?php echo e(__("message.home")); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(__("viewProducts")); ?></a></li>
            </ol>

        </div>
    </div>


    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-sm-6">
                        <h4><?php echo e(__("message.viewProducts")); ?></h4>

                    </div>
                    <div class="col-sm-6">
                        <a href="/products/create" class="btn btn-sm btn-primary pull-right"><i
                                    class="md md-add"></i> <?php echo e(__("message.AddNew")); ?></a>
                    </div>
                </div>

                <hr>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('success')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('failed')); ?>!</strong>
                    </div>
                <?php endif; ?>

                <?php if(isset($result)): ?>
                    <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th><?php echo e(__("message.BarCode")); ?></th>
                            <th><?php echo e(__("message.ProductTitle")); ?></th>
                            <th><?php echo e(__("message.ProductsCategory")); ?></th>
                            <th><?php echo e(__("message.ProductImage")); ?></th>
                            <th><?php echo e(__("message.ProductDescription")); ?></th>
                            <th><?php echo e(__("message.PurchasePrice")); ?></th>
                            <th><?php echo e(__("message.RetailPrice")); ?></th>
                            <th><?php echo e(__("message.Action")); ?></th>
                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($res->barcode); ?></td>
                                <td><?php echo e($res->product_name); ?></td>
                                <td><?php echo e($res->product_category_name); ?></td>
                                <td><img src="/images/products/<?php echo e($res->product_image); ?>" class="img-rounded"
                                         alt="Product image" width="150" height="80"></td>
                                <td><?php echo e($res->product_description); ?></td>
                                <td><?php echo e($res->product_purchase_price); ?></td>
                                <td><?php echo e($res->product_retail_price); ?></td>
                                <td>
                                    <button type="button"
                                            class="btn btn-sm btn-danger dropdown-toggle waves-effect waves-light"
                                            data-toggle="dropdown" aria-expanded="false"><?php echo e(__("message.Action")); ?><span
                                                class="caret"></span></button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item"
                                           href="/products/edit/<?php echo e($res->product_id); ?>"><i
                                                    class="fa fa-edit"></i> <?php echo e(__("message.Edit")); ?></a>
                                        <a class="dropdown-item"
                                           href="/products/destroy/<?php echo e($res->product_id); ?>/<?php echo e($res->product_details_id); ?>"><i
                                                    class="fa fa-remove"></i> <?php echo e(__("message.Delete")); ?></a>
                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>


                <?php endif; ?>
            </div>
            <!-- end row -->


        </div> <!-- end card-box -->
    </div><!-- end col -->
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>