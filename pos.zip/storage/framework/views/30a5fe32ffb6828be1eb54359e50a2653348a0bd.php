<?php $__env->startSection('title', 'Show Sells'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    


    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <form class="form-inline" method="post" action="/sell/search"
                                  enctype="multipart/form-data">

                                <div class="form-group col-md-4">
                                    <label class="col-5 col-form-label">From Date</label>
                                    <div class="col-7">
                                        <input type="text" class="form-control" name="from_date"
                                               placeholder="mm/dd/yyyy" id="datepicker-autoclose" required>
                                        <input type="hidden" class="form-control" name="_token"
                                               value="<?php echo e(csrf_token()); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-4">
                                    <label class="col-5 col-form-label">To Date</label>
                                    <div class="col-7">
                                        <input type="text" class="form-control" name="to_date" placeholder="mm/dd/yyyy"
                                               id="datepicker" required>

                                    </div>
                                </div>

                                


                                <div class="form-group mb-0 justify-content-end row col-md-2">
                                    <div class="col-10">
                                        <button type="submit" class="btn btn-info waves-effect waves-light">Search
                                        </button>
                                    </div>
                                </div>

                               <div class="dropdown show col-md-2">
                                        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Filter By
                                        </a>
                                      
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                          <a class="dropdown-item" href="/sell/list/due">Due</a>
                                          <a class="dropdown-item" href="/sell/list/paid">Paid</a>
                                         
                                        </div>
                             </div>
                            
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>View Sells 
                            
                            
                        <?php if(isset($from_date)): ?>
                          <span class="small">(from <?php echo e($from_date); ?> to <?php echo e($to_date); ?>)</span>
                        <?php endif; ?>
                        
                            
                        </h4>

                    </div>
                    
                </div>

                <hr>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('success')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('failed')); ?>!</strong>
                    </div>
                <?php endif; ?>

                <?php if(isset($result)): ?>
                    <table id="datatable-buttons" class="table table-striped table-bordered" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Name</th>
                            
                            <th> Phone</th>
                            <th> Address</th>
                            <th>Company</th>
                            <th>Price</th>
                            <th>Paid</th>
                            <th>Change</th>
                            <th>Due</th>
                            
                            <th>Discount</th>
                            <th>Status</th>
                            <th>Seller</th>
                            <th>Time</th>
                            <th>Action</th>
                        </tr>
                        </thead>


                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($res->customer_name); ?></td>
                                
                                <td><?php echo e($res->customer_phone); ?></td>
                                <td><?php echo e($res->customer_address); ?></td>
                                <td><?php echo e($res->customer_company); ?></td>
                                <td><?php echo e($res->grand_total_price); ?></td>
                                <td><?php echo e(($res->given_amount)+ getPayment($res->invoice)); ?></td>
                                <td><?php echo e($res->change); ?></td>
                                <td>
                                    <?php if($res->paid_status==1): ?>
                                        <span class="label label-success">Paid</span>
                                    <?php else: ?>
                                        <span class="text-danger"> <?php echo e($res->grand_total_price- ($res->given_amount+getPayment($res->invoice)+$res->discount_amount)); ?></span>

                                    <?php endif; ?>
                                </td>
                                
                                
                                <td><?php echo e($res->discount_amount); ?></td>

                                <td>
                                    <?php if($res->paid_status==1): ?>
                                        <span class="label label-success">Paid</span>
                                    <?php else: ?>

                                        <button type="button" class="btn btn-danger waves-effect waves-light"
                                                data-toggle="modal" data-target="#<?php echo e($res->sell_id); ?>">
                                            Due Pay
                                        </button>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($res->user_name); ?></td>
                                <td><?php echo e($res->created_at); ?></td>
                                <td>
                                    <button type="button"
                                            class="btn btn-sm btn-danger dropdown-toggle waves-effect waves-light"
                                            data-toggle="dropdown" aria-expanded="false">Action<span
                                                class="caret"></span></button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item"
                                           href="/sells/delete/<?php echo e($res->invoice); ?>"
                                           onclick="return confirm('Are you sure you want to delete this item')"><i
                                                    class="fa fa-trash"></i> Delete</a>
                                        <a class="dropdown-item"
                                           href="/sells/details/<?php echo e($res->invoice); ?>"><i
                                                    class="fa fa-align-right"></i> View Details</a>

                                        <a class="dropdown-item"
                                           href="/sells/payment/details/<?php echo e($res->invoice); ?>"><i
                                                    class="fa fa-align-right"></i> View Payments</a>
                                    </div>
                                </td>

                            </tr>

                            <div class="modal fade" tabindex="-1" id="<?php echo e($res->sell_id); ?>" role="dialog"
                                 aria-labelledby="mySmallModalLabel" aria-hidden="true" style="display: none;">
                                <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" id="mySmallModalLabel">Pay Now</h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                ×
                                            </button>
                                        </div>
                                        <div class="modal-body">

                                            <form class="form-horizontal" method="post"
                                                  action="/sell/pay"
                                                  enctype="multipart/form-data">

                                                <div class="form-group row" style="display: none">
                                                    <label class="col-3 col-form-label">ID</label>
                                                    <div class="col-9">
                                                        <input type="text" class="form-control" name="sell_id"
                                                               value="<?php echo e($res->sell_id); ?>">
                                                        <input type="hidden" class="form-control" name="_token"
                                                               value="<?php echo e(csrf_token()); ?>">
                                                        <input type="hidden" class="form-control" name="invoice"
                                                               value="<?php echo e($res->invoice); ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group row" style="display: none">
                                                    <label class="col-3 col-form-label">given_amount</label>
                                                    <div class="col-9">
                                                        <input type="text" class="form-control" name="given_amount"
                                                               value="<?php echo e($res->given_amount); ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-5 col-form-label">Pay Amount</label>
                                                    <div class="col-7">
                                                        <input type="text" class="form-control" name="pay_amount"
                                                               value="<?php echo e($res->grand_total_price- ($res->given_amount+getPayment($res->invoice)+$res->discount_amount)); ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group mb-0 justify-content-end row">
                                                    <div class="col-7">
                                                        <button type="submit"
                                                                class="btn btn-info waves-effect waves-light">Save
                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div><!-- /.modal-content -->
                                </div><!-- /.modal-dialog -->
                            </div><!-- /.modal -->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>


                <?php endif; ?>
            </div>
            <!-- end row -->


        </div> <!-- end card-box -->
    </div><!-- end col -->

    <!-- end row -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>