<?php $__env->startSection('title', 'Payments'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title">Payments</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="#">View Payments</a></li>
            </ol>

        </div>
    </div>


    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-sm-6">
                        <h4>View Payments</h4>

                    </div>

                </div>


                <?php if(isset($payments)): ?>
                    <table id="datatable-buttonsq" class="table table-striped table-bordered" cellspacing="0"
                           width="100%">
                        <thead>
                        <tr>
                            <th>Payment Date</th>
                            <th>Installment</th>
                            <th>Payment Amount</th>
                        </tr>
                        </thead>


                        <tbody>


                        <?php ($i=1); ?>
                        <?php ($grand_total=0); ?>
                        <tr>
                            <td><?php echo e(date('d-M-Y', strtotime($first_payment->created_at))); ?></td>
                            <td>Installment: <?php echo e($i++); ?> </td>
                            <td><?php echo e($first_payment->given_amount); ?></td>
                        </tr>

                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(date('d-M-Y', strtotime($res->created_at))); ?></td>
                                <td>Installment: <?php echo e($i++); ?> </td>
                                <td><?php echo e($res->pay_amount); ?></td>

                            </tr>

                            <?php $grand_total = ($grand_total + $res->pay_amount) ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                        <tfoot>
                        <tr>
                            <td>Total:</td>
                            <td><?php echo e($grand_total+$first_payment->given_amount); ?></td>
                        </tr>
                        </tfoot>
                    </table>


                <?php endif; ?>
            </div>
            <!-- end row -->
        </div> <!-- end card-box -->
    </div><!-- end col -->

    <!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>