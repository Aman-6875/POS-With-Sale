<!-- ========== Left Sidebar Start ========== -->

<div class="left side-menu">
    <div class="sidebar-inner slimscrollleft">
        <!--- Divider -->
        <div id="sidebar-menu">
            <ul>
                <li class="has_sub">
                    <a href="/" class="waves-effect"><i class="ti-home"></i>
                        <span> <?php echo e(__('message.dashboard')); ?> </span></a>
                </li>

                
                <li class="has_sub">
                    <a href="/pos" class="waves-effect"><i class="ti-receipt"></i>
                        <span> <?php echo e(__('message.pointofsell')); ?> </span></a>
                </li>


                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-users"></i> <span> <?php echo e(__('message.contacts')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    <ul class="list-unstyled">
                        <li><a href="/supplier/show"><?php echo e(__('message.suppliers')); ?></a></li>
                        <li><a href="/customer/show"><?php echo e(__('message.customers')); ?></a></li>
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ti-paint-roller"></i>
                        <span> <?php echo e(__('message.products')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    <ul class="list-unstyled">
                        <li><a href="/products/create"><?php echo e(__('message.addproducts')); ?></a></li>
                        <li><a href="/products/show"><?php echo e(__('message.listproducts')); ?></a></li>
                        
                        <li><a href="/product/category/show"><?php echo e(__('message.productcategories')); ?></a></li>
                        <li><a href="/sell/discount/show"><?php echo e(__('message.discount')); ?></a></li>
                        
                    </ul>
                </li>


                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ti-exchange-vertical"></i> <span> <?php echo e(__('message.expenses')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    <ul class="list-unstyled">
                        <li><a href="/expense/create"><?php echo e(__('message.addexpenses')); ?></a></li>
                        <li><a href="/expense/show"><?php echo e(__('message.listexpenses')); ?></a></li>
                        <li><a href="/expense/category/show"><?php echo e(__('message.expensecategories')); ?></a></li>
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-truck"></i>
                        <span><?php echo e(__('message.purchases')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    <ul class="list-unstyled">
                        <li><a href="/purchase/create"><?php echo e(__('message.productpurchase')); ?></a></li>
                        <li><a href="/purchase/show"><?php echo e(__('message.listproductpurchase')); ?></a></li>

                        <li><a href="/ingredient/purchase/create"><?php echo e(__('message.newpurchase')); ?></a></li>
                        

                    </ul>
                </li>
                

                <li class="has_sub">
                    <a href="/stock-history/show" class="waves-effect"><i class="fa fa-shopping-basket"></i>
                        <span><?php echo e(__('message.stock')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ti-shopping-cart"></i>
                        <span><?php echo e(__('message.sell')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    <ul class="list-unstyled">
                        <li><a href="/sell/list"><?php echo e(__('message.listsell')); ?></a></li>

                    </ul>
                </li>
                


                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ti-receipt"></i> <span> <?php echo e(__('message.reports')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    <ul class="list-unstyled">
                        <li><a href="/report/profit/show"><?php echo e(__('message.profitlos')); ?></a></li>
                        <li><a href="/report/sell/product"><?php echo e(__('message.sellbyproduct')); ?></a></li>
                        <li><a href="/report/sell/salesman"><?php echo e(__('message.salesmansold')); ?></a></li>
                        
                    </ul>
                </li>



                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="fa fa-support"></i><span> <?php echo e(__("message.settings")); ?> </span>
                        <span class="menu-arrow"></span></a>
                    <ul class="list-unstyled">
                     
                        <li><a href="/setting/shop"><?php echo e(__('message.shopsetting')); ?></a></li>
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="javascript:void(0);" class="waves-effect"><i class="ti-user"></i>
                        <span> <?php echo e(__('message.usermanagement')); ?> </span>
                        <span class="menu-arrow"></span> </a>
                    <ul class="list-unstyled">
                        <li><a href="/user/show"><?php echo e(__('message.user')); ?></a></li>
                       
                    </ul>
                </li>

                <li class="has_sub">
                    <a href="/logout" class="waves-effect"><i class="ti-receipt"></i>
                        <span> <?php echo e(__('message.logout')); ?> </span></a>
                </li>

            </ul>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- Left Sidebar End -->