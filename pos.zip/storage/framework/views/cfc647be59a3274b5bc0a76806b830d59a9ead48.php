<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h4 class="page-title">Quick Links</h4>
        <p class="text-muted page-title-alt">Click to see details !</p>
    </div>
</div>


<div class="row">
                           
            <div class="col-xl-2">
                                    
                <a href="/pos">
                                        
                    <div class="card-box">
                                        
                        <div class="bar-widget">
                                            
                            <div class="table-box">
                                                
                                <div class="table-detail">
                                                
                                    <div class="iconbox bg-info">
                                                
                                        <i class="ion-cube"></i>
                                                
                                    </div>
                                                
                                </div>

                                                
                                <div class="table-detail">
                                                    
                                    <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">POS</span></b></h4>
                                                
                                                
                                </div>

                                            
                            </div>
                                        
                        </div>
                                        
                    </div>
                                    
                </a>
                                    
            </div>
            <div class="col-xl-2">
                                    
                <a href="/products/show">
                                        
                    <div class="card-box">
                                        
                        <div class="bar-widget">
                                            
                            <div class="table-box">
                                                
                                <div class="table-detail">
                                                
                                    <div class="iconbox bg-info">
                                                
                                        <i class="fa fa-cart-plus"></i>
                                                
                                    </div>
                                                
                                </div>

                                                
                                <div class="table-detail">
                                                    
                                    <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">Products</span></b></h4>
                                                
                                                
                                </div>

                                            
                            </div>
                                        
                        </div>
                                        
                    </div>
                                    
                </a>
                                    
            </div>
            <div class="col-xl-2">
                                    
                <a href="/sell/list">
                                        
                    <div class="card-box">
                                        
                        <div class="bar-widget">
                                            
                            <div class="table-box">
                                                
                                <div class="table-detail">
                                                
                                    <div class="iconbox bg-info">
                                                
                                        <i class="ion-bag"></i>
                                                
                                    </div>
                                                
                                </div>

                                                
                                <div class="table-detail">
                                                    
                                    <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">Sells</span></b></h4>
                                                
                                                
                                </div>

                                            
                            </div>
                                        
                        </div>
                                        
                    </div>
                                    
                </a>
                                    
            </div>
            <div class="col-xl-2">
                                    
                <a href="/expense/show">
                                        
                    <div class="card-box">
                                        
                        <div class="bar-widget">
                                            
                            <div class="table-box">
                                                
                                <div class="table-detail">
                                                
                                    <div class="iconbox bg-info">
                                                
                                        <i class="ion-flash"></i>
                                                
                                    </div>
                                                
                                </div>

                                                
                                <div class="table-detail">
                                                    
                                    <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">Expenses</span></b></h4>
                                                
                                                
                                </div>

                                            
                            </div>
                                        
                        </div>
                                        
                    </div>
                                    
                </a>
                                    
            </div>
            <div class="col-xl-2">
                                    
                <a href="/purchase/show">
                                        
                    <div class="card-box">
                                        
                        <div class="bar-widget">
                                            
                            <div class="table-box">
                                                
                                <div class="table-detail">
                                                
                                    <div class="iconbox bg-info">
                                                
                                        <i class="ion-ios7-analytics"></i>
                                                
                                    </div>
                                                
                                </div>

                                                
                                <div class="table-detail">
                                                    
                                    <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">Purchases</span></b></h4>
                                                
                                                
                                </div>

                                            
                            </div>
                                        
                        </div>
                                        
                    </div>
                                    
                </a>
                                    
            </div>
            <div class="col-xl-2">
                                    
                <a href="/customer/show">
                                        
                    <div class="card-box">
                                        
                        <div class="bar-widget">
                                            
                            <div class="table-box">
                                                
                                <div class="table-detail">
                                                
                                    <div class="iconbox bg-info">
                                                
                                        <i class="ion-android-friends"></i>
                                                
                                    </div>
                                                
                                </div>

                                                
                                <div class="table-detail">
                                                    
                                    <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">Customers</span></b></h4>
                                                
                                                
                                </div>

                                            
                            </div>
                                        
                        </div>
                                        
                    </div>
                                    
                </a>
                                    
            </div>
            


</div>
<div class="row">
                           
    <div class="col-xl-2">
                            
        <a href="R">
                                
            <div class="card-box">
                                
                <div class="bar-widget">
                                    
                    <div class="table-box">
                                        
                        <div class="table-detail">
                                        
                            <div class="iconbox bg-info">
                                        
                                <i class="ion-clipboard"></i>
                                        
                            </div>
                                        
                        </div>

                                        
                        <div class="table-detail">
                                            
                            <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">Reports</span></b></h4>
                                        
                                        
                        </div>

                                    
                    </div>
                                
                </div>
                                
            </div>
                            
        </a>
                            
    </div>
    <div class="col-xl-2">
                            
        <a href="/user/show">
                                
            <div class="card-box">
                                
                <div class="bar-widget">
                                    
                    <div class="table-box">
                                        
                        <div class="table-detail">
                                        
                            <div class="iconbox bg-info">
                                        
                                <i class="ion-android-social-user"></i>
                                        
                            </div>
                                        
                        </div>

                                        
                        <div class="table-detail">
                                            
                            <h4 class="m-t-0 m-b-5"><b><span data-plugin="counterup">Users</span></b></h4>
                                        
                                        
                        </div>

                                    
                    </div>
                                
                </div>
                                
            </div>
                            
        </a>
                            
    </div>

    


</div>
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title">Daily Statistics</h4>
            <p class="text-muted page-title-alt">Click to see details !</p>
        </div>
    </div>

    <div class="row">

        <div class="col-md-6 col-lg-6 col-xl-3">
            <a href="/sell/list">
                <div class="widget-bg-color-icon card-box fadeInDown animated">
                    <div class="bg-icon bg-icon-info pull-left">
                        <i class="md md-attach-money text-info"></i>
                    </div>
                    <div class="text-right">
                        <h3 class="text-dark"><b class="counter">Tk <?php echo e($grand_total_price); ?></b></h3>
                        <p class="text-muted mb-0">Today's Total Sell</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>


        <div class="col-md-6 col-lg-6 col-xl-3">
            <a href="/sell/list">
                <div class="widget-bg-color-icon card-box">
                    <div class="bg-icon bg-icon-purple pull-left">
                        <i class="md md-add-shopping-cart text-purple"></i>
                    </div>
                    <div class="text-right">
                        <h3 class="text-dark"><b class="counter"><?php echo e($total_sell); ?> Items</b></h3>
                        <p class="text-muted mb-0">Today Product Sales</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>

        <div class="col-md-6 col-lg-6 col-xl-3">
            <a href="/expense/show">
                <div class="widget-bg-color-icon card-box">
                    <div class="bg-icon bg-icon-info pull-left">
                        <i class="md md-equalizer text-info"></i>
                    </div>
                    <div class="text-right">
                        <h3 class="text-dark"><b class="counter">Tk <?php echo e($total_expense); ?></b></h3>
                        <p class="text-muted mb-0">Expense</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>

        <div class="col-md-6 col-lg-6 col-xl-3">
            <a href="/sell/list">
                <div class="widget-bg-color-icon card-box">
                    <div class="bg-icon bg-icon-purple pull-left">
                        <i class="md md-remove-red-eye text-purple"></i>
                    </div>
                    <div class="text-right">
                        <h3 class="text-dark"><b class="counter">Tk <?php echo e($this_month_total_sell); ?></b></h3>
                        <p class="text-muted mb-0">This Month Total Sell</p>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

    
    

    <div class="row">

        <div class="col-8">

            <div class="portlet"><!-- /primary heading -->
                <div class="portlet-heading">
                    <h3 class="portlet-title text-dark text-uppercase">
                        Recent Sell
                    </h3>
                    <div class="portlet-widgets">
                        <a href="javascript:;" data-toggle="reload"><i class="ion-refresh"></i></a>
                        <span class="divider"></span>
                        <a data-toggle="collapse" data-parent="#accordion1" href="#portlet2"><i
                                    class="ion-minus-round"></i></a>
                        <span class="divider"></span>
                        <a href="#" data-toggle="remove"><i class="ion-close-round"></i></a>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div id="portlet2" class="panel-collapse collapse show">
                    <div class="portlet-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Customer Name</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Invoice</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><a href="/sells/details/<?php echo e($sell->invoice); ?>" class="text-dark"><b><?php echo e($i++); ?></b></a></td>
                                        <td><?php echo e($sell->customer_name); ?></td>
                                        <td>Tk <?php echo e($sell->grand_total_price); ?></td>
                                        <td>
                                            <?php if($sell->paid_status==1): ?>
                                                <span class="label label-info">Paid</span>
                                            <?php else: ?>
                                                <span class="label label-danger">Due</span>
                                            <?php endif; ?>

                                           </td>
                                        <td><?php echo e(date('d/m/Y'),strtotime($sell->created_at)); ?></td>
                                        <td><a href="/sells/details/<?php echo e($sell->invoice); ?>" class="text-dark"><p class="text-danger">Show</p></a></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- end col -->

    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>