<?php $__env->startSection('title', 'Show Sells'); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <div class="panel-body">
                   
                       <form method="GET" action="/daily-sale/product/result">
                        <div class="row">
                         <div class="col-md-5">
                                <select class="selectized" name="product_id">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($product->product_id); ?>">
                                             <?php echo e($product->product_name); ?>

                                         </option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                         </div> 
                         <div class="form-group row">
                            <label class="col-2 col-form-label">Out</label>
                            <div class="col-md-10">
                                <input type="number" class="form-control" name="out">
                            </div>
                        </div>                 
                         <div class="col-2">
                                    <button  type="submit" class="btn btn-info waves-effect waves-light">Add</button>
                         </div>
                        </div>
                       </form>
                 
                     

                    
                </div>
            </div>

        </div>

    </div>

    <!-- end row -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>