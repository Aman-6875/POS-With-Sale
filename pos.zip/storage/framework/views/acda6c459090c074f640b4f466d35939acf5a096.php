<?php $__env->startSection('title', 'Edit Supplier'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title"><?php echo e(__("message.Supplier")); ?></h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/"><?php echo e(__("message.home")); ?></a></li>
                <li class="breadcrumb-item"><a href="#"><?php echo e(__("message.EditSupplier")); ?></a></li>
            </ol>

        </div>
    </div>


    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title"><?php echo e(__("message.EditSupplier")); ?></h4>
                <hr>

                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('success')); ?>!</strong>
                    </div>
                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong><?php echo e(session('failed')); ?>!</strong>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <form class="form-horizontal" method="post" action="/supplier/update"
                                  enctype="multipart/form-data">

                                <div class="form-group row">
                                    <label class="col-2 col-form-label"><?php echo e(__("message.Name")); ?></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="supplier_name"
                                               value="<?php echo e($result->supplier_name); ?>">
                                        <input type="hidden" class="form-control" name="_token"
                                               value="<?php echo e(csrf_token()); ?>">
                                        <input type="hidden" class="form-control" name="supplier_id"
                                               value="<?php echo e($result->supplier_id); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label"><?php echo e(__("message.Email")); ?></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="supplier_email"
                                               value="<?php echo e($result->supplier_email); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label"><?php echo e(__("message.Phone")); ?></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="supplier_phone"
                                               value="<?php echo e($result->supplier_phone); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label"><?php echo e(__("message.Address")); ?></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="supplier_address"
                                               value="<?php echo e($result->supplier_address); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label"><?php echo e(__("message.Company")); ?></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="supplier_company"
                                               value="<?php echo e($result->supplier_company); ?>">
                                    </div>
                                </div>

                                <div class="form-group mb-0 justify-content-end row">
                                    <div class="col-10">
                                        <button type="submit" class="btn btn-info waves-effect waves-light"><?php echo e(__("message.Save")); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                <!-- end row -->

            </div> <!-- end card-box -->
        </div><!-- end col -->
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>