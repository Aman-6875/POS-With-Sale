<?php $__env->startSection('title', 'Create User'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title">User</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item"><a href="#">New User</a></li>
            </ol>

        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="m-t-0 header-title">New User</h4>
                <hr>

                <?php if(session('success')): ?>

                    <div class="alert alert-success"><?php echo e(session('success')); ?>!</div>

                <?php endif; ?>
                <?php if(session('failed')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('failed')); ?>!
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <div class="p-20">
                            <form class="form-horizontal" method="post" action="/user/store"
                                  enctype="multipart/form-data">

                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Name <span class="red-color">*</span></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="user_name">
                                        <input type="hidden" class="form-control" name="_token"
                                               value="<?php echo e(csrf_token()); ?>">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Email</label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="user_email" >
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Image</label>
                                    <div class="col-10">
                                        <input type="file" class="form-control" name="image">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Phone<span class="red-color">*</span></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="user_phone" required>
                                    </div>
                                </div>


                              

                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Password<span class="red-color">*</span></label>
                                    <div class="col-10">
                                        <input type="text" class="form-control" name="password" required>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label class="col-2 col-form-label">Type</label>
                                    <div class="col-10">
                                        <select class="form-control" name="user_type">
                                            <option value="1">Admin</option>
                                            <option value="2">Operator</option>
                                            <option value="3">Seller</option>
                                        </select>
                                    </div>
                                </div>

                               


                                <div class="form-group mb-0 justify-content-end row">
                                    <div class="col-10">
                                        <button type="submit" class="btn btn-info waves-effect waves-light">Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
                <!-- end row -->

            </div> <!-- end card-box -->
        </div><!-- end col -->
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>