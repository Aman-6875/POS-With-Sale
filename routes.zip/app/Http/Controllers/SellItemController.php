<?php

namespace App\Http\Controllers;

use App\SellItem;
use Illuminate\Http\Request;

class SellItemController extends Controller
{
    public function index()
    {
        //
    }


    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }


    public function show(SellItem $sellItem)
    {
        //
    }


    public function edit(SellItem $sellItem)
    {
        //
    }


    public function update(Request $request, SellItem $sellItem)
    {
        //
    }


    public function destroy(SellItem $sellItem)
    {
        //
    }
}
