<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profitlos extends Model
{
    //
}
